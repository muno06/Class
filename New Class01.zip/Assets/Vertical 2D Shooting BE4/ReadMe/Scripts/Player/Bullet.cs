using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bullet : MonoBehaviour
{

    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        transform.Translate(Vector2.up * Time.deltaTime * 5f);
        if(transform.localPosition.y > 15)
        {
            transform.position = Vector2.zero;
            gameObject.SetActive(false);
            PlayerController.instance_PlayerController.SetBullet(gameObject);
        }
    }
}
