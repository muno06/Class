using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    public static PlayerController instance_PlayerController;

    float speed;
    float DelayTime;

    [SerializeField] Sprite[] sr;
    [SerializeField] SpriteRenderer Playersprite;

    [SerializeField] Transform Rparent;
    [SerializeField] Transform parent;

    [SerializeField] GameObject bullet;
    Queue<GameObject> bullets = new Queue<GameObject>();

    [SerializeField] GameObject superbullet;
    Queue<GameObject> superbullets = new Queue<GameObject>();

    float BulletDelay = 1f;
    bool isSuperBullet = false;

    // Start is called before the first frame update
    void Start()
    {
        speed = 5f;
        instance_PlayerController = this;
    }

    // Update is called once per frame
    void Update()
    {
        float x = Input.GetAxisRaw("Horizontal") * Time.deltaTime * speed;
        float mx = Mathf.Clamp(transform.position.x + x, -2, 2);

        float y = Input.GetAxisRaw("Vertical") * Time.deltaTime * speed;
        float my = Mathf.Clamp(transform.position.y + y, -5, 5);

        transform.position = new Vector2(mx, my);

        if (x == 0)
        {
            Playersprite.sprite = sr[0]; 
        }
        else if (x > 0)
        {
            Playersprite.sprite = sr[1];
        }
        else
        {
            Playersprite.sprite = sr[2];
        }

        DelayTime += Time.deltaTime;
        if (DelayTime > BulletDelay)
        {
            Bullet();
            DelayTime = 0f;
        }

    }

    void Bullet()
    {
        if (isSuperBullet)
        {
            if (superbullets.Count == 0)
            {
                GameObject obj = Instantiate(superbullet, Rparent);
                obj.transform.SetParent(parent);
            }
            else
            {
                GameObject obj = superbullets.Dequeue();
                obj.SetActive(true);
                obj.transform.SetParent(Rparent);
                obj.transform.localPosition = Vector2.zero;
                obj.transform.SetParent(parent);
            }
        }
        else
        {
            if (bullets.Count == 0)
            {
                GameObject obj = Instantiate(bullet, Rparent);
                obj.transform.SetParent(parent);
            }
            else
            {
                GameObject obj = bullets.Dequeue();
                obj.SetActive(true);
                obj.transform.SetParent(Rparent);
                obj.transform.localPosition = Vector2.zero;
                obj.transform.SetParent(parent);
            }
        }
    }
    public void SetBullet(GameObject obj)
    {
        if (isSuperBullet)
            superbullets.Enqueue(obj);
        else
            bullets.Enqueue(obj);
    }
}
