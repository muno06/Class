using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Background : MonoBehaviour
{
    public static Background Instance_Background;

    // Start is called before the first frame update
    void Start()
    {
        Instance_Background = this;
    }

    // Update is called once per frame
    public void Move(GameObject background, int speed)
    {
        background.transform.Translate(Vector2.down * Time.deltaTime * speed);
        if(background.transform.localPosition.y < -24)
        {
            background.transform.localPosition = Vector2.zero;

        }

    }
}
